import React from 'react'
import Play from './Play'

const StartExam = () => {
  return (
    <div>
      <Play />
    </div>
  )
}

export default StartExam